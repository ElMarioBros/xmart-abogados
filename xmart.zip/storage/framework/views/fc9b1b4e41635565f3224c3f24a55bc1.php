

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="mb-3 ml-5">Crear nuevo usuario</h1>

    <div class="ml-5">
        <?php if (isset($component)) { $__componentOriginal32d3a6eefb04992da10a97b4e6e9ebf1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal32d3a6eefb04992da10a97b4e6e9ebf1 = $attributes; } ?>
<?php $component = App\View\Components\BackButton::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('back-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BackButton::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal32d3a6eefb04992da10a97b4e6e9ebf1)): ?>
<?php $attributes = $__attributesOriginal32d3a6eefb04992da10a97b4e6e9ebf1; ?>
<?php unset($__attributesOriginal32d3a6eefb04992da10a97b4e6e9ebf1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal32d3a6eefb04992da10a97b4e6e9ebf1)): ?>
<?php $component = $__componentOriginal32d3a6eefb04992da10a97b4e6e9ebf1; ?>
<?php unset($__componentOriginal32d3a6eefb04992da10a97b4e6e9ebf1); ?>
<?php endif; ?>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success w-50 m-auto mb-3" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="w-50 m-auto mt-2">
    <form action="<?php echo e(route('user.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <h5 class="fs-5 mb-3">Informacion del usuario</h5>
        <div class="mb-3">
            <label for="name" class="form-label">Nombre del Usuario</label>
            <input type="text" class="form-control" id="name" name="name" placeholder="Ej. Juan Sanchez Gonzalez">
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">Correo Electrónico del Usuario</label>
            <input type="text" class="form-control" id="email" name="email" placeholder="Ej. jsanchez@mail.com">
        </div>

        <div class="mb-3">
            <label for="password" class="form-label">Contraseña del Usuario</label>
            <input type="password" class="form-control" id="password" name="password" placeholder="***********">
        </div>

        <div class="mb-3">
            <label for="password_confirmation" class="form-label">Confirmar Contraseña del Usuario</label>
            <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="***********">
        </div>

        <button type="submit" class="btn btn-primary mb-5">Registrar</button>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Productos-modernos\xmart\resources\views/create-user.blade.php ENDPATH**/ ?>